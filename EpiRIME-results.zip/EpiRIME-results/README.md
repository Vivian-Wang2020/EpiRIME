# EpiRIME: experimental results

Raw results of all experiments of the EpiRIME paper.
All tables and figures of the paper and its supplementary materials can be computed from these files. The code
that produces them is provided in a separate package.

## Benchmark experiments (`benchmark/`)

CEC2017 with D = 30 and 50 (functions F1, F3 to F30) and CEC2022 with D = 10 and 20 (F1 to F12). Twelve algorithms:
L-SHADE, BWDE, TCDE, DPSDE, RIME, IRIME, HRIME-MSP, TERIME, DNMRIME, MRIME-CD, HDRIME, and EpiRIME. Budget: 1000 D
function evaluations; 30 runs per function. Run r on function F used the seed 2026 + 7 F + 20 r for all algorithms,
so the results are paired by run.

* `final_fitness.csv`: one row per run with the best fitness found. The optimum of the function is not subtracted.
* `convergence_<suite>_D<dim>.json.gz`: best-so-far fitness of every run at 50 equally spaced points of the budget,
  `best_fitness[algorithm][function][run][point]`.
* `cpu_time.csv`: single-thread CPU time of every run in seconds. All twelve algorithms were run in one batch job on
  one compute node.

## Ablation analysis (`ablation/`)

Four versions on the same functions, budget, and seeds: RIME, RIME + S1 (droplet-accretion soft-rime search only),
RIME + S2 (lattice-oriented puncture only), and EpiRIME. The files have the same format as in `benchmark/`; the rows
of RIME and EpiRIME are the runs of the benchmark experiments.

## Sensitivity analysis (`sensitivity/`)

EpiRIME with ten values of the nucleus-pool ratio rho (0.01, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.5), in
the format of `benchmark/`; the column `algorithm` holds the value of rho. The rows of rho = 0.3 are the EpiRIME runs
of the benchmark experiments.

## Gene selection (`gene_selection/`)

Nine head and neck cancer datasets (GEO series GSE12452, GSE53819, GSE59102, GSE143224, GSE107591, GSE30784,
GSE25099, GSE37991, and GSE13601), each with the 2000 probes of largest variance. Nine algorithms: HRO-GWO, RBNRO-DE,
GOG-MBSHO, iBABC-CGO, BHOA-CM, BPRGO, AIEEFO, SPHMO, and EpiRIME. Budget: 20,000 fitness evaluations; 30 runs per
dataset. In run r, all algorithms used the same patient-level 70/30 split, given by `split_seed`.

* `runs.csv`: one row per run with the training fitness of the best solution, the number of selected genes, its
  leave-one-patient-out balanced error on the training samples, and its balanced error on the held-out test
  patients (KNN classifier with k = 3).
* `selected_genes.json.gz`: the selected genes of every run, `selected[dataset][algorithm][run]`, as 0-based column
  indices into the data matrix of the processed dataset.
* `convergence.json.gz`: best-so-far training fitness at 50 equally spaced points of the budget,
  `best_training_fitness[dataset][algorithm][run][point]`.
